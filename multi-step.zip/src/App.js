import React, { Component } from 'react';
import { connect } from 'react-redux';
import { Redirect, Route, Switch } from 'react-router-dom';
import { FormUserDetails } from './components/FormUserDetails';
import { FormPersonalDetails } from './components/FormPersonalDetails';
import { Confirm } from './components/Confirm';
import { Success } from './components/Success';

class App extends Component {
  constructor () {
    super();
    this.state = {
      firstName: '',
      lastName: '',
      email: '',
      occupation: '',
      city: '',
      bio: ''
    };
  }

  updateFormState = (values) => {
    console.log(values);
    this.setState(state => ({
      ...state,
      ...values,
    }));
  }

  resetForm = () => {
    this.setState({
      firstName: '',
      lastName: '',
      email: '',
      occupation: '',
      city: '',
      bio: ''
    });
  }

  render() {
    console.log(this.props.userDetails);
    return (
      <Switch>
        <Route path="/" exact>
          <Redirect to="/userdetails" />
        </Route>
        <Route path="/userdetails">
          <FormUserDetails
            formData={this.state}
            setFormData={this.updateFormState}
          />
        </Route>
        <Route path="/personaldetails">
          <FormPersonalDetails
            formData={this.state}
            setFormData={this.updateFormState}
          />
        </Route>
        <Route path="/confirm">
          <Confirm
            formData={this.state}
            formReset={this.resetForm}
          />
        </Route>
        <Route path="/success">
          <Success userDetails={this.props.userDetails} />
        </Route>
      </Switch>
    );
  };
}

const mapStateToProps = (state) => ({
  userDetails: state.userDetails.userDetails,
});

export default connect(mapStateToProps)(App);