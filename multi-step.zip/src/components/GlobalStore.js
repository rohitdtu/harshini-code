import { combineReducers } from 'redux';

const initialState = {
	userDetails: [],
};

const UserReducer = (state = initialState, action) => {
	if (action.type === 'SUBMIT_USER_DETAILS') {
		const { userDetails } = state;
		userDetails.push(action.data);
		return {
			...state,
			userDetails: userDetails,
		}
	}
	return {
		...state,
	}
};

const RootReducer = combineReducers({
	userDetails: UserReducer,
});

export default RootReducer;
