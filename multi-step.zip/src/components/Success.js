import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import { Header } from './Header';
import { useHistory } from 'react-router';

const useStyles = makeStyles(theme => ({
  textCenter: {
    textAlign: 'center'
  }
}));

export const Success = ({userDetails}) => {
  const history = useHistory();
  const classes = useStyles();
  return (
    <>
      <div className={classes.textCenter}>
        <Header title='Success' />
        <h1>Thank You For Your Submission</h1>
        <p>You will get an email with further instructions</p>
      </div>
      <div>
        <h1>Here is the list of user details</h1>
        {
          userDetails.map((user, index) => (
            <div className="container" key={index}>
              <p>name: {user.firstName} {user.lastName}</p>
              <p>email: {user.email}</p>
              <p>Occupation: {user.occupation}</p>
              <p>City: {user.city}</p>
              <p>Bio: {user.bio}</p>
            </div>
          ))
        }
      </div>
      <button onClick={() => history.push('/')}>Home</button>
    </>
  );
};
