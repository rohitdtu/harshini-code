import React from 'react';
import { shallow } from 'enzyme';
import {Header} from '../Header';
import { makeStyles } from '@material-ui/core/styles';


const useStyles = makeStyles(theme => ({
  root: {
    flexGrow: 1
  },
  title: {
    margin: 'auto'
  }
}));

let wrapped = shallow(<Header title='Confirm User Data'/>);
describe('Title', () => {
  it('should render the Title Component correctly', () => {   
    expect(wrapped).toMatchSnapshot();
  });
});