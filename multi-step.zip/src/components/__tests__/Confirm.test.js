import React from 'react';
import { shallow } from 'enzyme';
import { makeStyles } from '@material-ui/core/styles';
import { Confirm } from '../Confirm';
import { Provider } from 'react-redux';

const useStyles = makeStyles(theme => ({
  textCenter: {
    textAlign: 'center'
  },
  button: {
    margin: theme.spacing(1)
  }
}));

describe('Title', () => {
	it('render confirmation page with correct data', () => {
		const emptyfunc = () => {};
		const dummyUserData = {
			firstName: 'firstname',
			lastName: 'lastname',
			email: 'test@test.com',
			occupation: 'test occupation data',
			city: 'random city',
			bio: 'this is a random testing data'
		};
		let wrapped = shallow(<Provider store={{getState: emptyfunc}}><Confirm formData={dummyUserData} formReset={emptyfunc} /></Provider>);
		expect(wrapped).toMatchSnapshot();
	});
});